The program must have an input file entitled "input.txt" which is in the following format:

[number of elements]
Array elements which are space separated.

Note: [] for clarity

ex:
10
100 20 15 3 4 8 7 -1 0 33